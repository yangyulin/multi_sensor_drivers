# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "".split(';') if "" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "launch_sensor"
PROJECT_SPACE_DIR = "/home/lin/Data/workspace/catkin_ws_sara/src/rs_pointgrey_microstrain/launch_sensor/cmake-build-debug/devel"
PROJECT_VERSION = "2.2.3"
