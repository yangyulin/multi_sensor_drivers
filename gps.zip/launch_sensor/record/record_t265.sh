source /opt/ros/melodic/setup.bash

rosbag record \
	/camera/accel/sample \
	/camera/gyro/sample \
	/camera/fisheye1/image_raw \
	/camera/fisheye2/image_raw \
	/imu_ms/data


	
	
	

